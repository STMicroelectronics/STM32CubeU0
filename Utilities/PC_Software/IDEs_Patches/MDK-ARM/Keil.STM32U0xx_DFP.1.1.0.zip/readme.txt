 /**
  **********************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U0 devices support on EWARM.
  **********************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *********************************************************************************************************************/

Package general purpose:
  ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32U0 devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal use only.
  
  Running the "Keil.STM32U0xx_DFP.1.1.0.pack" adds the following: 
  ================================================================================================================================ 
   1. Part numbers for  :
	- Product lines with 256KB: STM32U083xCxx/STM32U073xCxx
	- Product lines with 128KB: STM32U073xBxx
	- Product lines with 64KB: STM32U073x8xx/STM32U031x8xx
	- Product lines with 32KB: STM32U031x6xx
	- Product lines with 16KB: STM32U031x4xx
   2. Automatic STM32U0 flash algorithm selection 
		
   3. STM32U0 SVD file v0r3.


  How to use:
 =================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32U0xx_DFP.1.1.0.pack" in order to install this pack in 
	  the Keil install directory.
	
PS: Please make sure that you are using PackUnzip.exe to run this pack.


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32U0xx_DFP.1.1.0.pack" in order to install this pack in 
the Keil install directory.

SVD files ReleaseNotes:
 =======================
	=======================================================
	STM32U083_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact with Crypto
	Missing Timers (2/3/15/16)/Comp2/I2C4
	
	=======================================================
	STM32U083_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U083_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#

	=======================================================
	STM32U073_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact W/O Crypto
	Missing Timers (2/3/15/16)/Comp2/I2C4
	
	Clean up for non related bitfields
	
	=======================================================
	STM32U073_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U073_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#


	=======================================================
	STM32U031_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact
	(without AES/USB/CRS/LCD/LPTIM3/LPUART3/COMP2/SPI3/I2C4)
	
	Missing Timers (2/3/15/16)
	
	Clean up for non related bitfields
	
	=======================================================
	STM32U031_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U031_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#







	



