  /**
  **********************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U0 devices support on EWARM.
  **********************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *********************************************************************************************************************/

  Package general purpose:
  ======================================================================================================================
	These packages contains the needed files to be installed in order to support STM32U0 devices by EWARM9 and laters.

	We inform you that this package is suitable for internal & external use.
	EWARMv9_STM32U0xx_V1.1.0.exe has been digitally signed by STMicroelectronics.
	
  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ================================================================ 
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
     - Part Numbers with 256KB Flash size: STM32U073xC/U083xC  
     - Part Numbers with 128KB Flash size: STM32U073xB
     - Part Numbers with 64KB Flash size: STM32U073x8/STM32U031x8
     - Part Numbers with 32KB Flash size: STM32U031x6
     - Part Numbers with 16KB Flash size: STM32U031x4
	
     -Automatic STM32U0x flash algorithm selection
   
	3. The following SVD files will be added:
	- STM32U083, STM32U073 & STM32U031  SVD files v0r3.
	

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32U0xx_V1.1.0.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
 
 
 SVD files ReleaseNotes:
 =======================
	=======================================================
	STM32U083_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact with Crypto
	Missing Timers (2/3/15/16)/Comp2/I2C4
	
	=======================================================
	STM32U083_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U083_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#

	=======================================================
	STM32U073_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact W/O Crypto
	Missing Timers (2/3/15/16)/Comp2/I2C4
	
	Clean up for non related bitfields
	
	=======================================================
	STM32U073_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U073_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#


	=======================================================
	STM32U031_v0r1:     initial release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Initilal release derived from IPxact
	(without AES/USB/CRS/LCD/LPTIM3/LPUART3/COMP2/SPI3/I2C4)
	
	Missing Timers (2/3/15/16)
	
	Clean up for non related bitfields
	
	=======================================================
	STM32U031_v0r2:     second release
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Update in Flash (FLASH_OPTR/FLASH_SECR) & remove non related registers
	
	#Update License section#
	
	=======================================================
	STM32U031_v0r3:     Update
	=======================================================
	Doc ID: RM0503 Rev 0.1 - 11 May 2023
	
	Adding support for TIM2/TIM3/TIM15/TIM16 from IPxact
	(Refer to STM32G0x1 reference manual 'RM0444' for details)
	
	#Complete support#





	



